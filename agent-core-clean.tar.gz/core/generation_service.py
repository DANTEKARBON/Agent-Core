import time
import yaml
from typing import Dict, Any, List, Optional
from core.contracts import LLMResponse
from core.cache import TTLCache
from core.resilience import with_retry, with_timeout
from core.errors import FallbackExhaustedError
from adapters.factory import LLMAdapterFactory
from logger_config import logger

class GenerationService:
    def __init__(self, config=None, model_manager=None, cache=None, **kwargs):
        self.model_manager = model_manager
        self.cache = cache if cache else TTLCache(ttl_seconds=3600, enabled=True)
        
        if config is None:
            with open("config.yaml", "r") as f:
                config = yaml.safe_load(f)
        self.config = config
        
        self.adapters = {}
        models_cfg = self.config.get("models", {})
        primary_cfg = self.config.get("llm_backends", {}).get("primary", {})
        default_max_tokens = primary_cfg.get("max_tokens", 800)      # увеличен дефолт
        default_temperature = primary_cfg.get("temperature", 0.7)
        
        for model_name, model_info in models_cfg.items():
            port = model_info.get("port")
            if not port:
                continue
            backend_config = {
                "type": "mlx_openai",
                "base_url": f"http://127.0.0.1:{port}",
                "model_name": model_name,
                "max_tokens": default_max_tokens,
                "temperature": default_temperature,
            }
            try:
                adapter = LLMAdapterFactory.create(backend_config)
                self.adapters[model_name] = adapter
                logger.info(f"Адаптер для {model_name} создан через фабрику на {backend_config['base_url']} с max_tokens={default_max_tokens}")
            except Exception as e:
                logger.error(f"Не удалось создать адаптер для {model_name}: {e}")
        
        self.fallback_chain = self.config.get("fallback_chain", ["phi3", "coder"])
        self._last_metrics = {}

    def _ensure_model_loaded(self, model_name: str) -> bool:
        if not self.model_manager:
            return True
        model_info = self.config.get("models", {}).get(model_name)
        if not model_info:
            logger.error(f"Модель {model_name} не найдена в конфиге")
            return False
        return self.model_manager.load_model(model_name, model_info["port"], model_info["path"])

    def _get_cache_key(self, prompt: str, model_name: str) -> str:
        return f"{model_name}:{prompt}"

    @with_retry(attempts=2, delay=1.0)
    @with_timeout(seconds=30)
    def _call_adapter(self, adapter, prompt: str, template_key: str = None):
        prompts_cfg = self.config.get("prompts", {})
        if template_key and template_key in prompts_cfg:
            template = prompts_cfg[template_key].get("template", "")
            if template:
                prompt = template.format(query=prompt)
        
        # Явно берём max_tokens из конфига модели (или из primary)
        model_name = getattr(adapter, 'model_name', template_key)
        models_cfg = self.config.get("models", {})
        primary_cfg = self.config.get("llm_backends", {}).get("primary", {})
        max_tokens = primary_cfg.get("max_tokens", 800)
        temperature = primary_cfg.get("temperature", 0.7)
        
        # Переопределяем для конкретной модели, если есть отдельные настройки
        if model_name in models_cfg:
            # можно добавить per-model max_tokens в будущем
            pass
        
        logger.info(f"Вызов адаптера для {model_name} с max_tokens={max_tokens}, temp={temperature}")
        # Используем generate_contract с явными параметрами
        return adapter.generate_contract(prompt, max_tokens=max_tokens, temperature=temperature)

    def generate(self, target_role: str, prompt: str) -> str:
        self._ensure_model_loaded(target_role)
        
        candidates = [target_role] if target_role else []
        for m in self.fallback_chain:
            if m not in candidates:
                candidates.append(m)
        
        tried = set()
        last_error = None
        
        for model_name in candidates:
            if model_name in tried:
                continue
            tried.add(model_name)
            
            adapter = self.adapters.get(model_name)
            if adapter is None:
                logger.warning(f"Нет адаптера для {model_name}")
                continue
            
            cache_key = self._get_cache_key(prompt, model_name)
            cached = self.cache.get(cache_key)
            if cached:
                logger.info(f"Кэш hit для {model_name}")
                return cached
            
            try:
                start = time.time()
                resp: LLMResponse = self._call_adapter(adapter, prompt, template_key=model_name)
                elapsed_ms = (time.time() - start) * 1000
                
                if resp.status == "error":
                    logger.error(f"Ошибка генерации для {model_name}: {resp.error}")
                    continue
                
                tokens_in = resp.prompt_tokens
                tokens_out = resp.completion_tokens
                tok_per_sec = (tokens_out / elapsed_ms) * 1000 if elapsed_ms > 0 else 0
                
                self._last_metrics = {
                    "in": tokens_in,
                    "out": tokens_out,
                    "ms": elapsed_ms,
                    "t/s": tok_per_sec,
                    "model": model_name,
                    "ttft_ms": resp.ttft_ms,
                }
                
                logger.info(f"⚡ {model_name} генерация", extra={
                    "in": tokens_in, "out": tokens_out,
                    "ms": f"{elapsed_ms:.0f}", "t/s": f"{tok_per_sec:.1f}",
                    "ttft_ms": f"{resp.ttft_ms:.0f}" if resp.ttft_ms else "N/A"
                })
                
                response_text = resp.text
                self.cache.set(cache_key, response_text)
                return response_text
            except Exception as e:
                logger.warning(f"{model_name} упала: {e}, пробуем следующую")
                last_error = e
                continue
        
        raise FallbackExhaustedError(f"Все модели {candidates} не смогли ответить. Последняя ошибка: {last_error}")

    def get_last_metrics(self) -> dict:
        return self._last_metrics

    def clear_cache(self):
        self.cache.clear()
        logger.info("Кэш генерации очищен")

    def reset_context(self):
        logger.debug("Сброс контекста генерации (не реализован)")

    def get_cache_stats(self):
        return self.cache.stats()
