from dataclasses import dataclass
from typing import Optional, Dict, Any

@dataclass
class LLMResponse:
    text: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    finish_reason: Optional[str] = None
    model_name: Optional[str] = None
    status: str = "success"  # 'success' or 'error'
    error: Optional[str] = None
    ttft_ms: Optional[float] = None  # время до первого токена (ms)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LLMResponse":
        return cls(
            text=data.get("text", ""),
            prompt_tokens=data.get("prompt_tokens", 0),
            completion_tokens=data.get("completion_tokens", 0),
            total_tokens=data.get("total_tokens", 0),
            finish_reason=data.get("finish_reason"),
            model_name=data.get("model_name"),
            status=data.get("status", "success"),
            error=data.get("error"),
            ttft_ms=data.get("ttft_ms")
        )
