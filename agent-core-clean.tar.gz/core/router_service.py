import logging
from typing import Optional
from core.contracts import LLMResponse
from core.cache import TTLCache
from adapters.factory import LLMAdapterFactory
from model_manager import ModelManager
from core.resilience import with_timeout, with_retry
from logger_config import logger

class RouterService:
    def __init__(self, primary_adapter, prompts, config, model_manager: ModelManager, cache: TTLCache):
        self.primary_adapter = primary_adapter
        self.prompts = prompts
        self.config = config
        self.model_manager = model_manager
        self.cache = cache
        
        self.phi3_adapter = None
        phi3_config = self.config.get("models", {}).get("phi3")
        if phi3_config:
            self.phi3_adapter = LLMAdapterFactory.create({
                "type": "mlx_openai",
                "base_url": f"http://127.0.0.1:{phi3_config['port']}",
                "model_name": "phi3",
                "max_tokens": 5,
                "temperature": 0.0
            })
            logger.info("Адаптер роутера (phi3) инициализирован")
        else:
            logger.warning("Модель phi3 не найдена в конфиге, роутер будет использовать primary")

        resilience_cfg = config.get("resilience", {})
        self.timeout_seconds = resilience_cfg.get("timeout_seconds", 30)
        self.retry_attempts = resilience_cfg.get("retry_attempts", 2)
        self.retry_delay = resilience_cfg.get("retry_delay_seconds", 1.0)

    def _ensure_model_loaded(self, model_name: str) -> bool:
        model_info = self.config["models"].get(model_name)
        if not model_info:
            logger.error(f"Модель {model_name} не найдена в конфиге")
            return False
        return self.model_manager.load_model(model_name, model_info["port"], model_info["path"])

    def _call_llm_for_classification(self, adapter, prompt: str) -> Optional[str]:
        try:
            @with_retry(max_attempts=self.retry_attempts, delay=self.retry_delay)
            @with_timeout(self.timeout_seconds)
            def call():
                return adapter.generate_contract(prompt, max_tokens=5, temperature=0.0)
            
            result: LLMResponse = call()
            if result.status == "error":
                logger.error(f"Ошибка классификации: {result.error}")
                return None
            
            raw_response = result.text.strip().lower()
            for marker in ["<|end|>", "<|user|>", "<|assistant|>", "<|system|>"]:
                if marker in raw_response:
                    raw_response = raw_response.split(marker)[0].strip()
            
            logger.info(f"Сырой ответ классификатора: {raw_response}")
            first_word = raw_response.split()[0] if raw_response else ""
            logger.info(f"Первое слово: {first_word}")
            
            if first_word in ("coder", "reasoner", "phi3"):
                return first_word
            else:
                logger.warning(f"Неверная классификация от {adapter.__class__.__name__}: {first_word}")
                return None
        except Exception as e:
            logger.error(f"Ошибка LLM классификации: {e}")
            return None

    def classify(self, query: str) -> str:
        cache_key_params = {"max_tokens": 5, "temperature": 0.0}
        cached = self.cache.get(query, "router", cache_key_params)
        if cached is not None:
            logger.info(f"Кэш классификации hit, возвращаем {cached}")
            return cached

        router_prompt_template = self.prompts.get("router", {}).get("template", "")
        if not router_prompt_template:
            logger.error("Шаблон промпта для роутера не найден")
            return "phi3"
        prompt = router_prompt_template.format(query=query)

        classification = None
        if self.phi3_adapter:
            self._ensure_model_loaded("phi3")
            classification = self._call_llm_for_classification(self.phi3_adapter, prompt)
            if classification:
                logger.info(f"Роутер phi3 успешно определил: {classification}")
        
        if not classification:
            logger.info("Переключаемся на primary (reasoner) для классификации")
            router_model_name = self.config.get("llm_backends", {}).get("primary", {}).get("model_name")
            if router_model_name:
                self._ensure_model_loaded(router_model_name)
            else:
                router_model_name = "reasoner"
                self._ensure_model_loaded(router_model_name)
            
            classification = self._call_llm_for_classification(self.primary_adapter, prompt)
            if not classification:
                logger.error("Оба роутера (phi3 и reasoner) не смогли классифицировать, используем phi3 по умолчанию")
                classification = "phi3"
        
        self.cache.set(query, "router", classification, cache_key_params)
        return classification

    def clear_cache(self):
        if hasattr(self, 'cache') and self.cache:
            self.cache.clear()
            logger.info("Кэш роутера очищен")
