import time
import json
import logging
from collections import OrderedDict
from typing import Any, Optional, Dict
from threading import Lock

logger = logging.getLogger(__name__)

class TTLCache:
    def __init__(self, ttl_seconds: int = 3600, max_size: int = 1000, enabled: bool = True):
        self.ttl = ttl_seconds
        self.max_size = max_size
        self.enabled = enabled
        self._cache = OrderedDict()
        self._lock = Lock()

    def _clean_expired(self):
        if not self.enabled:
            return
        now = time.time()
        keys_to_delete = []
        for key, (value, expiry) in self._cache.items():
            if expiry <= now:
                keys_to_delete.append(key)
        for key in keys_to_delete:
            del self._cache[key]

    def get(self, key: str, *args, **kwargs) -> Optional[Any]:
        if not self.enabled:
            return None
        with self._lock:
            self._clean_expired()
            if key not in self._cache:
                return None
            value, expiry = self._cache.pop(key)
            if expiry <= time.time():
                return None
            self._cache[key] = (value, expiry)
            return value

    def set(self, key: str, value: Any, *args, **kwargs):
        if not self.enabled:
            return
        with self._lock:
            self._clean_expired()
            if key in self._cache:
                self._cache.pop(key)
            elif len(self._cache) >= self.max_size:
                self._cache.popitem(last=False)
            expiry = time.time() + self.ttl
            self._cache[key] = (value, expiry)

    def clear(self):
        with self._lock:
            self._cache.clear()

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            self._clean_expired()
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "ttl": self.ttl,
                "enabled": self.enabled
            }

    def save(self, filepath: str):
        with self._lock:
            data = {}
            for key, (value, expiry) in self._cache.items():
                str_key = json.dumps(key) if not isinstance(key, str) else key
                data[str_key] = [value, expiry]
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            logger.info(f"Кэш сохранён в {filepath}")
        except Exception as e:
            logger.error(f"Ошибка сохранения кэша: {e}")

    def load(self, filepath: str):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            with self._lock:
                self._cache.clear()
                for key_str, (value, expiry) in data.items():
                    try:
                        key = json.loads(key_str) if key_str.startswith('[') else key_str
                    except:
                        key = key_str
                    if expiry > time.time():
                        self._cache[key] = (value, expiry)
            logger.info(f"Кэш загружен из {filepath}, {len(self._cache)} записей")
        except FileNotFoundError:
            logger.info(f"Файл кэша {filepath} не найден, создаём новый")
        except Exception as e:
            logger.error(f"Ошибка загрузки кэша: {e}")
